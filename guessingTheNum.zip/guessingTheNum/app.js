let maximum = parseInt(prompt("Enter the maximum number"));

while (!maximum) {
    maximum = parseInt(prompt("Enter a valid number"));
}

const targetNum = Math.floor(Math.random() * maximum) + 1;

let guess = prompt("Enter your first guess!");

let attempts = 1;

while (parseInt(guess) !== targetNum) {

    attempts++;

    if (guess === 'q') {
        break;
    }

    if (guess < targetNum) {
        guess = prompt("Too less");
    } else if (guess > targetNum) {
        guess = prompt("Too High");
        document.getElementById('heading').innerHTML = 'Too High';
    } else {
        guess = prompt('Invalid input');
        document.getElementById('heading').innerHTML = 'Invalid input';
    }
}

if (guess.toLowerCase() === 'q') {
    console.log("You have quit the game...")
    document.getElementById('heading').innerHTML = 'You Quit';
} else {
    console.log(`Yayy! You got it. It took you ${attempts} guesses.`)
    document.getElementById('heading').innerHTML = `Number of attempts : ${attempts}`;
}

