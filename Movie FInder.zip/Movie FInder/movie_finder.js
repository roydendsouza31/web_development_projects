const API_URL = "http://www.omdbapi.com/?i=tt3896198&apikey=60471585&s=";
const API_URL_SEARCH = "http://www.omdbapi.com/?apikey=60471585&i=";

document.getElementById("searchButton").addEventListener("click", function () {
    const searchQuery = document.getElementById("searchInput").value;
    console.log(searchQuery);
    if (searchQuery) {
        getMovies(API_URL + searchQuery);
    }
});

async function getMovies(url) {
    const response = await fetch(url);
    const responseData = await response.json();
    console.log(responseData);
    showMovies(responseData.Search);
}

function showMovies(movies) {
    document.getElementById("movieCards").innerHTML = "";
    movies.forEach(async function (movie) {
        const movieData = await fetch(API_URL_SEARCH + movie.imdbID);
        const movieDataObj = await movieData.json();
        displayMovies(movieDataObj);
    });
}

function displayMovies(imovie) {
    const movieElement = document.createElement("div");
    movieElement.classList.add("movieCard");
    movieElement.innerHTML = `
        <div class="card">
            <img src="${imovie.Poster}" alt="Poster" width="300px" height="300px"/>
            <br>
            <div class="movie-description">
                <span class="movie-title"><b>Title</b><span class="value">${imovie.Title}</span></span>
                <span class="movie-title"><b>Rating</b><span class="value">${imovie.imdbRating}</span></span>
                <span class="movie-title"><b>Director</b><span class="value">${imovie.Director}</span></span>
                <span class="movie-title"><b>Release Date</b><span class="value">${imovie.Released}</span></span>
                <span class="movie-title"><b>Genre</b><span class="value">${imovie.Genre}</span></span>
            </div>
        </div>
    `;
    document.getElementById("movieCards").appendChild(movieElement);
}

